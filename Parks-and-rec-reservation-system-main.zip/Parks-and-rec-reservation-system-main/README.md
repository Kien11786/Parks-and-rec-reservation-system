# City Connect 🌳
A smart San Jose parks and recreation reservation system.

## Features
- Reserve time slots at parks and rec centers
- View real-time availability
- Filter by park amenities
- Report park issues
- Chatbot assistant for park info
